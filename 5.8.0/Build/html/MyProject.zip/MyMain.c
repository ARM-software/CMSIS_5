#include "RTE_Components.h"             // Component selection
#include CMSIS_device_header            // Device header
#include <math.h>
#include <stdlib.h>

#define TABLE_SIZE 1000
float sin_table[TABLE_SIZE];

int main (void) {
  unsigned int i, max_i;
  float f = 0.0;

  max_i = TABLE_SIZE - (rand() % 500);
  for (i = 0; i < max_i; i++) {
    sin_table[i] = sinf(f);
    f = f + (3.141592 / TABLE_SIZE);
  }
  return 1;
}
